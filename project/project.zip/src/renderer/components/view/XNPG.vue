<template>
 <div>
     效能评估
 </div>
</template>

<script>

 export default {
  name:'XNPG',
  props:[''],
  data () {
   return {

   };
  },

  components: {},


  beforeMount() {},

  mounted() {},

  methods: {},


 }

</script>
<style  scoped>

</style>