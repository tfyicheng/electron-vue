<template>
 <div>
     777
 </div>
</template>

<script>

 export default {
  name:'',
  props:[''],
  data () {
   return {

   };
  },

  components: {},


  beforeMount() {},

  mounted() {},

  methods: {},


 }

</script>
<style  scoped>

</style>