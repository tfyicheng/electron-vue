<template>
    
    <div class="btn">
      <i class="iconfont icon-zuixiaohua" @click="handleMin"></i>
      <i class="iconfont icon-zuidahuaxi" @click="handleMax"></i>
      <i class="iconfont icon-guanbixi" @click="exit"></i>
    </div>
</template>

<script>
export default {
    name:"topmenu",
}
</script>

<style>

</style>